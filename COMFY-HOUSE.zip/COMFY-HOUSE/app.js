//variables

const cartBtn = document.querySelector(".cart-btn");
const closeCartBtn = document.querySelector(".close-cart");
const clearCartBtn = document.querySelector(".clear-cart");

const cartDOM = document.querySelector(".cart");
const cartOverlay = document.querySelector(".cart-overlay");

const cartItems = document.querySelector(".cart-items");

const cartTotal = document.querySelector(".cart-total");

const cartContent = document.querySelector(".cart-content");

const productsDOM = document.querySelector(".products-center");

// cart
let cart = [];

//buttons
let buttonsDOM = [];

//getting the products
class Products {
  async getProducts() {
    try {
      let result = await fetch("products.json");

      //console.log(result);

      let data = await result.json(); //getting data in json format

      //console.log(data);

      let products = data.items; //get all item of json file into                                    the products variable

      //console.log(typeof result); //objectm
      //console.log(typeof data); //object
      //console.log(typeof products);  //object
      //console.log(products); //shows all products

      products = products.map(item => {
        const { title } = item.fields;
        const { price } = item.fields;
        const { id } = item.sys;
        const image = item.fields.image.fields.file.url;

        //console.log(title, price);

        return { title, price, id, image };
      });
      return products;
    } catch (error) {
      console.log(error);
    }
  }
}

//display products
class UI {
  displayProducts(products) {
    let result = "";

    // console.log(products);

    products.forEach(product => {
      result += `
    

            <!-- Single product -->

 
 
  <article class="product">
          <div class="img-container">
            <img
              src=${product.image}
              alt="product"
              class="product-img"
            />
            <button class="bag-btn dat" id="change" data-id=${product.id}>
              <i class="fas fa-shopping-car"></i>
              Add to bag
            </button>
          </div>
          <h3>${product.title}</h3>
          <h4>$${product.price}</h4>
        </article>

     
 
      <!-- end of single product -->


    `;
    });

    productsDOM.innerHTML = result;
  }

  getBagButtons() {
    //const Buttonss = document.querySelectorAll(".bag-btn"); //nodelist
    //console.log(Buttonss);

    const buttons = [...document.querySelectorAll(".bag-btn")]; //array
    buttonsDOM = buttons; //
    //console.log(buttons);

    buttons.forEach(button => {
      //getting one button at a time
      //let id1 = button.dataset.id; //another method to get id
      //console.log(id1);
      //console.log("hello");
      //console.log(button);

      let id = button.getAttribute("data-id"); //string

      //console.log(id);

      //console.log(button);

      let inCart = cart.find(item => item.id === id);

      if (inCart) {
        button.innerText = "In Cart";
        button.disabled = true;
      }
      button.addEventListener("click", event => {
        //console.log(event);

        event.target.innerText = "In Cart";
        event.target.disabled = true;
        //button.disabled = true;

        // 1] get product from products
        let cartItem = { ...Storage.getProduct(id), amount: 1 };

        //        console.log(cartItem);

        // 2] add product to the cart

        cart = [...cart, cartItem];
        //      console.log(cart);

        // 3] save cart in local storage
        Storage.saveCart(cart);

        // 4] set cart value
        this.setCartValues(cart);

        //add cart item

        //5] display cart item
        this.addCartItem(cartItem);

        // 6] show the cart
        UI.showCart();
      });
    });
  }
  setCartValues(cart) {
    let tempTotal = 0;
    let itemsTotal = 0;
    cart.map(item => {
      tempTotal += item.price * item.amount;
      itemsTotal += item.amount;
    });
    cartTotal.innerText = parseFloat(tempTotal.toFixed(2));
    cartItems.innerText = itemsTotal;

    // console.log(cartTotal, cartItems);
  }

  addCartItem(item) {
    const div = document.createElement("div");
    div.classList.add("cart-item");

    div.innerHTML = `<img src=${item.image} />

            <div>
              <h4>${item.title}</h4>
              <h5>$${item.price}</h5>
              <span class="remove-item" data-id="${item.id}"> remove </span>
            </div>

            <div>
              <i class="fas fa-chevron-up" data-id="${item.id}"></i>
              <p id="pitem" class="item-amount">${item.amount}</p>
              <i class="fas fa-chevron-down" data-id="${item.id}" ></i>
            </div>
  
    `;
    cartContent.appendChild(div);
    //console.log(cartContent);
  }

  static hideCart() {
    cartOverlay.classList.remove("transparentBcg");
    cartDOM.classList.remove("showCart");
  }

  static showCart() {
    cartOverlay.classList.add("transparentBcg");
    cartDOM.classList.add("showCart");
  }

  setupAPP() {
    cart = Storage.getCart();
    this.setCartValues(cart);
    this.populateCart(cart);
    closeCartBtn.addEventListener("click", UI.hideCart);
    cartBtn.addEventListener("click", UI.showCart);
  }
  populateCart(cart) {
    cart.forEach(item => {
      this.addCartItem(item);
    });
  }
  cartLogic() {
    //clear cart button
    clearCartBtn.addEventListener("click", () => {
      this.clearCart();
    });

    //cart functionality

    cartContent.addEventListener("click", event => {
      //call back function

      //console.log(event.target.classList.contains("remove-item"));

      if (event.target.classList.contains("remove-item")) {
        let removeItem = event.target;

        //console.log(removeItem);

        //let id = removeItem.getAttribute("data-id"); //another method to                                             get id from HTML

        let id = removeItem.getAttribute("data-id");
        //console.log(id);

        //console.log(removeItem.parentElement.parentElement); // get all parent child of cart-items example- img remove btn up down

        cartContent.removeChild(removeItem.parentElement.parentElement);

        this.removeItem(id);
      } else if (event.target.classList.contains("fa-chevron-up")) {
        let addAmount = event.target;
        let id = addAmount.getAttribute("data-id");
        //console.log(id);

        let tempItem = cart.find(item => item.id === id);
        //console.log(tempItem);
        tempItem.amount += 1;
        Storage.saveCart(cart);
        this.setCartValues(cart);
        addAmount.nextElementSibling.innerText = tempItem.amount;
      } else if (event.target.classList.contains("fa-chevron-down")) {
        let subAmount = event.target;
        let id = subAmount.getAttribute("data-id");
        //console.log(id);

        let tempItem = cart.find(item => item.id === id);
        //console.log(tempItem);
        tempItem.amount -= 1;

        if (tempItem.amount > 0) {
          Storage.saveCart(cart);
          this.setCartValues(cart);
          subAmount.previousElementSibling.innerText = tempItem.amount;
        } else {
          cartContent.removeChild(subAmount.parentElement.parentElement);
          this.removeItem(id);
        }
      }
    });
  }

  clearCart() {
    //console.log(this);
    let cartItems = cart.map(item => item.id);

    //console.log(cart); //it shows all title image price id
    //console.log(cartItems); //it only shows the cart id
    //console.log(typeof Items); //type of cart and cartItems is object
    //this.removeItem("3");   //pass value for function is working or not

    cartItems.forEach(id => this.removeItem(id));

    //console.log(cartContent.children.length);

    while (cartContent.children.length > 0) {
      cartContent.removeChild(cartContent.children[0]);
    }
    UI.hideCart();
  }

  //this method is use for remove element from storage and change the button from disable to enable and also change the button inner text.

  removeItem(id) {
    cart = cart.filter(item => item.id !== id); // this fn is also use                                        to remove single item from cart
    this.setCartValues(cart);
    Storage.saveCart(cart);
    let button = this.getSingleButton(id);
    button.disabled = false;

    //document.getElementById("change").innerText = "Add to cart";
    // above line is not working because of we uses loop to display the products . means template

    button.innerHTML = `<i class="fas fa-shopping-car"></i>
     Add to Cart`;
  }

  getSingleButton(id) {
    return buttonsDOM.find(button => button.getAttribute("data-id") === id);
  }
}

//local storage
class Storage {
  static saveProducts(products) {
    localStorage.setItem("Products", JSON.stringify(products));
  }

  static getProduct(id) {
    let Products = JSON.parse(localStorage.getItem("Products"));
    return Products.find(product => product.id === id); //returns the                                            particular product object
  }
  static saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
  }
  static getCart() {
    return localStorage.getItem("cart")
      ? JSON.parse(localStorage.getItem("cart"))
      : [];
  }
}

/*

document.addEventListener("DOMContentLoaded", load);

function load() {
  const ui = new UI();
  const products = new Products();

  //get all products

  // products.getProducts().then(products => console.log(products));

  products.getProducts().then(products => ui.displayProducts(products));
}

*/

document.addEventListener("DOMContentLoaded", () => {
  const ui = new UI();
  const products = new Products();

  // setup APP
  ui.setupAPP();
  //closeCartBtn.addEventListener("click", UI.hideCart);
  //cartBtn.addEventListener("click", UI.showCart);
  //get all products

  // products.getProducts().then(products => console.log(products));

  products
    .getProducts()
    .then(products => {
      ui.displayProducts(products);
      //console.log(products);
      Storage.saveProducts(products);
    })
    .then(() => {
      ui.getBagButtons();
      ui.cartLogic();
    });
});
